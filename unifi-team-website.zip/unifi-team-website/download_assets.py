#!/usr/bin/env python3
"""
Download all Figma assets used by the static site.

IMPORTANT:
Figma MCP asset URLs are temporary. Run this file soon after receiving the
project. Once the files are downloaded into /assets, the website no longer
depends on those temporary URLs.
"""
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
import time

ASSETS = {'unifi-logo.png': 'https://www.figma.com/api/mcp/asset/921fee8d-02a1-44f9-9a94-ea5a60202c1d/798f5.png', 'hero-art.png': 'https://www.figma.com/api/mcp/asset/921fee8d-02a1-44f9-9a94-ea5a60202c1d/55bf0.png', 'hero-shadow.svg': 'https://www.figma.com/api/mcp/asset/921fee8d-02a1-44f9-9a94-ea5a60202c1d/48415.svg', 'capability-acquire.png': 'https://www.figma.com/api/mcp/asset/a3b1b959-d156-44c7-8218-78caf9235481/8f5b6.png', 'capability-engage.png': 'https://www.figma.com/api/mcp/asset/a3b1b959-d156-44c7-8218-78caf9235481/779df.png', 'capability-convert.png': 'https://www.figma.com/api/mcp/asset/a3b1b959-d156-44c7-8218-78caf9235481/f286c.png', 'capability-optimise.png': 'https://www.figma.com/api/mcp/asset/a3b1b959-d156-44c7-8218-78caf9235481/637a1.png', 'capability-transform.png': 'https://www.figma.com/api/mcp/asset/a3b1b959-d156-44c7-8218-78caf9235481/c6a88.png', 'transformation-then.png': 'https://www.figma.com/api/mcp/asset/fa16343b-62a6-4eef-af8f-471a2d592b67/75dae.png', 'transformation-shift.png': 'https://www.figma.com/api/mcp/asset/fa16343b-62a6-4eef-af8f-471a2d592b67/5038a.png', 'transformation-now.png': 'https://www.figma.com/api/mcp/asset/fa16343b-62a6-4eef-af8f-471a2d592b67/4819b.png', 'journey-phone.png': 'https://www.figma.com/api/mcp/asset/cbf237c7-da63-41cf-a717-9b8cd4b77f4a/175ba.png', 'team-hiew.png': 'https://www.figma.com/api/mcp/asset/ab08f672-a322-4393-865f-ff424373d898/5caae.png', 'team-fatima.png': 'https://www.figma.com/api/mcp/asset/ab08f672-a322-4393-865f-ff424373d898/40c64.png', 'team-stephen.png': 'https://www.figma.com/api/mcp/asset/ab08f672-a322-4393-865f-ff424373d898/884e1.png', 'team-afifah.png': 'https://www.figma.com/api/mcp/asset/ab08f672-a322-4393-865f-ff424373d898/ea351.png', 'team-farhan.png': 'https://www.figma.com/api/mcp/asset/ab08f672-a322-4393-865f-ff424373d898/428d0.png', 'team-hazirah.png': 'https://www.figma.com/api/mcp/asset/ab08f672-a322-4393-865f-ff424373d898/8d54e.png', 'team-najmi.png': 'https://www.figma.com/api/mcp/asset/ab08f672-a322-4393-865f-ff424373d898/45a51.png', 'voice-hiew.png': 'https://www.figma.com/api/mcp/asset/8917db22-3a1a-43ed-ad21-133bbc8fdf66/eb183.png', 'voice-farhan.png': 'https://www.figma.com/api/mcp/asset/8917db22-3a1a-43ed-ad21-133bbc8fdf66/ff41f.png', 'voice-afifah.png': 'https://www.figma.com/api/mcp/asset/8917db22-3a1a-43ed-ad21-133bbc8fdf66/85e3f.png', 'voice-najmi.png': 'https://www.figma.com/api/mcp/asset/8917db22-3a1a-43ed-ad21-133bbc8fdf66/7735c.png', 'voice-hazirah.png': 'https://www.figma.com/api/mcp/asset/8917db22-3a1a-43ed-ad21-133bbc8fdf66/4278c.png', 'voice-stephen.png': 'https://www.figma.com/api/mcp/asset/8917db22-3a1a-43ed-ad21-133bbc8fdf66/a32b2.png', 'voice-fatima.png': 'https://www.figma.com/api/mcp/asset/8917db22-3a1a-43ed-ad21-133bbc8fdf66/67ca8.png', 'achievement-01.png': 'https://www.figma.com/api/mcp/asset/9a8a67a9-0082-41e3-8797-92127d453fd5/91efc.png', 'achievement-02.png': 'https://www.figma.com/api/mcp/asset/9a8a67a9-0082-41e3-8797-92127d453fd5/9735c.png', 'achievement-03.png': 'https://www.figma.com/api/mcp/asset/9a8a67a9-0082-41e3-8797-92127d453fd5/40b06.png', 'achievement-04.png': 'https://www.figma.com/api/mcp/asset/9a8a67a9-0082-41e3-8797-92127d453fd5/6faae.png', 'achievement-05.png': 'https://www.figma.com/api/mcp/asset/9a8a67a9-0082-41e3-8797-92127d453fd5/2b49f.png', 'achievement-06.png': 'https://www.figma.com/api/mcp/asset/9a8a67a9-0082-41e3-8797-92127d453fd5/be008.png', 'achievement-07.png': 'https://www.figma.com/api/mcp/asset/9a8a67a9-0082-41e3-8797-92127d453fd5/88523.png', 'achievement-08.png': 'https://www.figma.com/api/mcp/asset/9a8a67a9-0082-41e3-8797-92127d453fd5/46699.png', 'achievement-09.png': 'https://www.figma.com/api/mcp/asset/9a8a67a9-0082-41e3-8797-92127d453fd5/eea28.png', 'achievement-10.png': 'https://www.figma.com/api/mcp/asset/9a8a67a9-0082-41e3-8797-92127d453fd5/0d788.png', 'achievement-11.png': 'https://www.figma.com/api/mcp/asset/9a8a67a9-0082-41e3-8797-92127d453fd5/05901.png', 'achievement-12.png': 'https://www.figma.com/api/mcp/asset/9a8a67a9-0082-41e3-8797-92127d453fd5/9e650.png', 'achievement-13.png': 'https://www.figma.com/api/mcp/asset/9a8a67a9-0082-41e3-8797-92127d453fd5/e2b36.png', 'work-step-1.png': 'https://www.figma.com/api/mcp/asset/5c7b5550-4ab7-4d49-a21c-e2fb326ee9ae/362d3.png', 'work-step-2.png': 'https://www.figma.com/api/mcp/asset/5c7b5550-4ab7-4d49-a21c-e2fb326ee9ae/5eb17.png', 'work-step-3.png': 'https://www.figma.com/api/mcp/asset/5c7b5550-4ab7-4d49-a21c-e2fb326ee9ae/e3a52.png', 'work-step-4.png': 'https://www.figma.com/api/mcp/asset/5c7b5550-4ab7-4d49-a21c-e2fb326ee9ae/d3c0f.png', 'work-step-5.png': 'https://www.figma.com/api/mcp/asset/5c7b5550-4ab7-4d49-a21c-e2fb326ee9ae/0c0d4.png', 'work-step-6.png': 'https://www.figma.com/api/mcp/asset/5c7b5550-4ab7-4d49-a21c-e2fb326ee9ae/57fb9.png', 'moment-01.png': 'https://www.figma.com/api/mcp/asset/6072559e-d558-4a14-ba48-41240745835e/0e3bc.png', 'moment-02.png': 'https://www.figma.com/api/mcp/asset/6072559e-d558-4a14-ba48-41240745835e/70312.png', 'moment-03.png': 'https://www.figma.com/api/mcp/asset/6072559e-d558-4a14-ba48-41240745835e/96b29.png', 'moment-04.png': 'https://www.figma.com/api/mcp/asset/6072559e-d558-4a14-ba48-41240745835e/48be6.png', 'moment-05.png': 'https://www.figma.com/api/mcp/asset/6072559e-d558-4a14-ba48-41240745835e/3c833.png', 'moment-06.png': 'https://www.figma.com/api/mcp/asset/6072559e-d558-4a14-ba48-41240745835e/aac2c.png', 'future-ring-1.png': 'https://www.figma.com/api/mcp/asset/fdeca4c7-9000-4106-8d1c-dd91f650c6ee/2878e.png', 'future-ring-2.png': 'https://www.figma.com/api/mcp/asset/fdeca4c7-9000-4106-8d1c-dd91f650c6ee/468fa.png', 'future-ring-3.png': 'https://www.figma.com/api/mcp/asset/fdeca4c7-9000-4106-8d1c-dd91f650c6ee/6f174.png', 'future-ring-4.png': 'https://www.figma.com/api/mcp/asset/fdeca4c7-9000-4106-8d1c-dd91f650c6ee/878c1.png', 'future-ring-5.png': 'https://www.figma.com/api/mcp/asset/fdeca4c7-9000-4106-8d1c-dd91f650c6ee/cc42a.png', 'future-ring-6.png': 'https://www.figma.com/api/mcp/asset/fdeca4c7-9000-4106-8d1c-dd91f650c6ee/eb66b.png', 'smile-badge.svg': 'https://www.figma.com/api/mcp/asset/fdeca4c7-9000-4106-8d1c-dd91f650c6ee/db6ed.svg', 'footer-unifi.png': 'https://www.figma.com/api/mcp/asset/f9bb312f-19fc-4b58-9089-3de1c00f4522/8a9df.png', 'scrapbook-01.png': 'https://www.figma.com/api/mcp/asset/d2d2ef20-2ccd-484d-8066-78b42d676716/48be6.png', 'scrapbook-02.png': 'https://www.figma.com/api/mcp/asset/d2d2ef20-2ccd-484d-8066-78b42d676716/e3814.png', 'scrapbook-03.png': 'https://www.figma.com/api/mcp/asset/d2d2ef20-2ccd-484d-8066-78b42d676716/9914a.png', 'scrapbook-04.png': 'https://www.figma.com/api/mcp/asset/d2d2ef20-2ccd-484d-8066-78b42d676716/791b0.png', 'scrapbook-05.png': 'https://www.figma.com/api/mcp/asset/d2d2ef20-2ccd-484d-8066-78b42d676716/4a85f.png'}

root = Path(__file__).resolve().parent / "assets"
root.mkdir(parents=True, exist_ok=True)

ok = 0
failed = []
for name, url in ASSETS.items():
    dest = root / name
    if dest.exists() and dest.stat().st_size > 0:
        print(f"[skip] {name}")
        ok += 1
        continue
    print(f"[get ] {name}")
    try:
        req = Request(url, headers={"User-Agent":"Mozilla/5.0"})
        with urlopen(req, timeout=45) as r, open(dest, "wb") as f:
            f.write(r.read())
        ok += 1
        time.sleep(0.05)
    except (URLError, HTTPError, TimeoutError) as e:
        failed.append((name, str(e)))
        print(f"[FAIL] {name}: {e}")

print(f"\nDownloaded/available: {ok}/{len(ASSETS)}")
if failed:
    print("\nFailed files:")
    for name, error in failed:
        print(f" - {name}: {error}")
    print("\nThe Figma links may have expired. Ask ChatGPT to refresh the asset manifest from the Figma file.")
else:
    print("\nAll assets are local. Open index.html or use VS Code Live Server.")
