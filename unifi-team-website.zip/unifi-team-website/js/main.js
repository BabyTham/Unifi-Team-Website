const achievements = [
  {title:"Marketing Excellence 2025",category:"TEAM RECOGNITION",description:"Recognised among the Unifi and Unifi Business team after multiple Gold and Bronze wins across major 2025 campaigns.",impact:"Gold + Bronze campaign wins"},
  {title:"IMPAK BIZ",category:"FEATURED INITIATIVE",description:"End-to-end digital platform delivery spanning requirements, UI/UX, development, testing, deployment, production support and digital tracking.",impact:"End-to-end platform delivery"},
  {title:"TaaS PI-5 Migration",category:"PLATFORM MIGRATION",description:"Supported the 2026 platform transition, including eShop DVT readiness and continuity of customer journeys during migration.",impact:"2026 migration readiness"},
  {title:"UDP Program Revamp",category:"PARTNER PROGRAMME",description:"Led the 2026 revamp of the Unifi Developer Partnership programme and refreshed its digital purchase journey.",impact:"Refreshed UDP purchase journey"},
  {title:"4 New UDP Projects",category:"2026 DELIVERY",description:"Successfully launched four new Unifi Developer Partnership projects in 2026.",impact:"4 projects launched"},
  {title:"Unifi eShop Experience",category:"DIGITAL COMMERCE",description:"Business and performance insights improved the Devices and Postpaid purchase journey across Unifi eShop.",impact:"Improved Devices + Postpaid journeys"},
  {title:"WhatsApp Integration",category:"CUSTOMER ASSISTANCE",description:"Added direct agent assistance to reduce friction during online registration and application journeys.",impact:"Lower-friction assisted journeys"},
  {title:"Operational Excellence & Growth",category:"OPERATIONS",description:"Strengthened productivity, customer lifecycle management, retention and fallout reduction through data-driven process improvement.",impact:"Productivity + retention improvements"},
  {title:"iJoin Journey Revamp",category:"JOURNEY OPTIMISATION",description:"Product-owned journey revamp focused on stakeholder delivery timelines and reducing customer drop-off before completion.",impact:"Focused on reducing drop-off"},
  {title:"Unifi TV Journey Revamp",category:"DIGITAL EXPERIENCE",description:"Led the iDiscovery and purchase journey revamp to simplify navigation, improve content clarity and create a smoother purchase experience.",impact:"Smoother Unifi TV purchase journey"},
  {title:"FIFA World Cup 2026",category:"CAMPAIGN EXPERIENCE",description:"Delivered the FIFA World Cup 2026 microsite in June to support campaign objectives through a dedicated digital experience.",impact:"Dedicated campaign microsite"},
  {title:"SEO & Organic Growth",category:"ORGANIC PERFORMANCE",description:"Ongoing Unifi Portal SEO optimisation in 2025/2026 improved organic visibility and contributed to growth in organic traffic.",impact:"Improved organic visibility"},
  {title:"Smarthome +200%",category:"CONVERSION IMPACT",description:"Targeted special deals through the iJoin intercept contributed to a 200% increase in Smarthome bundle sales in May.",impact:"+200% Smarthome bundle sales"}
];

const team = [
  {name:"HIEW FONG FONG",persona:"The Strategist",focus:"Acquisition Strategy & Growth",description:"Sets the direction, shapes the acquisition strategy and drives the overall digital growth agenda.",image:"assets/team-hiew.png"},
  {name:"FATIMA NUR ZAHRA",persona:"The Business Champion",focus:"Business Portal & Digital Growth",description:"Drives the Business Portal experience, enabling businesses to discover, engage and transact digitally.",image:"assets/team-fatima.png"},
  {name:"STEPHEN JEGANATHAN",persona:"The Campaign Driver",focus:"Digital Campaigns & Acquisition",description:"Turns campaigns into acquisition opportunities, driving traffic, engagement and sales.",image:"assets/team-stephen.png"},
  {name:"WAN AFIFAH NAJIHAH",persona:"The Optimiser",focus:"Sales Performance & Conversion",description:"Turns data and insights into action, optimising the digital funnel to improve conversion and maximise sales.",image:"assets/team-afifah.png"},
  {name:"FARHAN AL HAFIZ",persona:"The Revenue Commander",focus:"Digital Operations & Sales Recovery",description:"Leads a 30-person operations force to process, recover and maximise every sales lead — turning opportunities that could be lost into revenue.",image:"assets/team-farhan.png"},
  {name:"NUR HAZIRAH",persona:"The Digital Enabler",focus:"Website Enablement & Digital Health",description:"Brings campaigns and launches to life digitally, while keeping the website healthy, reliable and always ready for business.",image:"assets/team-hazirah.png"},
  {name:"AHMAD NAJMI",persona:"The Content Strategist",focus:"Web Content & Customer Experience",description:"Transforms product information into clear, engaging content that helps customers understand, choose and convert.",image:"assets/team-najmi.png"}
];

const track = document.querySelector("#achievement-track");
const prev = document.querySelector("#achievement-prev");
const next = document.querySelector("#achievement-next");
const count = document.querySelector("#achievement-count");
const progress = document.querySelector("#achievement-progress");
let index = 0;

achievements.forEach((item, i) => {
  const card = document.createElement("article");
  card.className = "achievement-card";
  card.innerHTML = `
    <img src="assets/achievement-${String(i+1).padStart(2,"0")}.png" alt="${item.title}">
    <div class="body">
      <h3>${item.title}</h3>
      <span class="category">${item.category}</span>
      <p>${item.description}</p>
      <strong>${item.impact}</strong>
    </div>`;
  track.appendChild(card);
});

function cardsVisible(){
  if (window.innerWidth < 620) return 1;
  if (window.innerWidth < 980) return 2;
  return 3;
}
function updateCarousel(){
  const card = track.querySelector(".achievement-card");
  if (!card) return;
  const gap = 24;
  const width = card.getBoundingClientRect().width + gap;
  const maxIndex = Math.max(0, achievements.length - cardsVisible());
  index = Math.min(Math.max(index,0),maxIndex);
  track.style.transform = `translateX(-${index*width}px)`;
  count.textContent = String(index+1).padStart(2,"0");
  progress.style.width = `${Math.max(8,((index+cardsVisible())/achievements.length)*100)}%`;
  prev.classList.toggle("active",index>0);
  next.classList.toggle("active",index<maxIndex);
}
prev.addEventListener("click",()=>{ index--; updateCarousel(); });
next.addEventListener("click",()=>{ index++; updateCarousel(); });
window.addEventListener("resize",updateCarousel);
updateCarousel();

// Mobile nav
const menu = document.querySelector(".mobile-menu");
const navLinks = document.querySelector("#nav-links");
menu.addEventListener("click",()=>{
  const open = navLinks.classList.toggle("open");
  menu.setAttribute("aria-expanded",String(open));
});
navLinks.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>navLinks.classList.remove("open")));

// Team profile modal
const profileModal = document.querySelector("#profile-modal");
document.querySelectorAll(".team-card").forEach(card=>{
  card.addEventListener("click",()=>{
    const m = team[Number(card.dataset.member)];
    document.querySelector("#profile-image").src = m.image;
    document.querySelector("#profile-image").alt = m.name;
    document.querySelector("#profile-persona").textContent = m.persona;
    document.querySelector("#profile-name").textContent = m.name;
    document.querySelector("#profile-focus").textContent = m.focus;
    document.querySelector("#profile-description").textContent = m.description;
    profileModal.showModal();
  });
});
document.querySelector("[data-close-profile]").addEventListener("click",()=>profileModal.close());
profileModal.addEventListener("click",e=>{ if(e.target===profileModal) profileModal.close(); });

// Gallery modal
const galleryModal = document.querySelector("#gallery-modal");
document.querySelector("#open-gallery").addEventListener("click",()=>galleryModal.showModal());
document.querySelector("[data-close-gallery]").addEventListener("click",()=>galleryModal.close());
galleryModal.addEventListener("click",e=>{ if(e.target===galleryModal) galleryModal.close(); });

// Simple reveal-on-scroll animation
const observer = new IntersectionObserver(entries=>{
  entries.forEach(entry=>{
    if(entry.isIntersecting){
      entry.target.classList.add("in-view");
      observer.unobserve(entry.target);
    }
  });
},{threshold:.12});
document.querySelectorAll("main section").forEach(section=>{
  section.style.opacity = "0";
  section.style.transform = "translateY(18px)";
  section.style.transition = "opacity .55s ease, transform .55s ease";
  observer.observe(section);
});
const style = document.createElement("style");
style.textContent = "main section.in-view{opacity:1!important;transform:none!important}";
document.head.appendChild(style);
