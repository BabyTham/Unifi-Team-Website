# Unifi Digital Acquisition Team — Static Website

This project converts the latest **Figma "Unifi Team Website Revised"** design into plain:

- HTML
- CSS
- JavaScript

There is no framework, no npm install, and no build step.

## 1. Download the Figma assets first

The code intentionally points to local files under `assets/`.

Run:

### Windows
```powershell
py download_assets.py
```

or:

```powershell
python download_assets.py
```

### macOS / Linux
```bash
python3 download_assets.py
```

Figma asset URLs are short-lived, so run this soon. After the assets are downloaded, the site is independent of Figma's temporary URLs.

## 2. Preview locally

### Easiest
Open `index.html` in your browser.

### Recommended
In VS Code, install **Live Server**, then right-click `index.html` → **Open with Live Server**.

## 3. What is implemented

- Responsive hero + navigation
- Figma-inspired hero floating motion
- Who We Are / capability flow
- Impact metrics
- Transformation
- Browse-to-Buy journey
- Before & After comparison
- Meet the Seven transition
- Team profile cards + click-to-open profile modal
- Team quotes
- Interactive 13-card Greatest Hits carousel
- How We Work
- Behind the Scenes polaroid section
- Scrapbook-style Our Moments modal
- What's Next
- Footer + smooth anchor navigation
- Desktop / tablet / mobile responsive rules

## 4. Before public deployment

1. Replace `team@example.com` in `index.html` with the approved contact.
2. Confirm that TM/Unifi approves publishing the content and photos publicly.
3. Run `download_assets.py` and verify the `assets/` folder is fully populated.
4. Test on desktop and mobile.
5. Push the entire folder to GitHub.
6. Connect the repository to Cloudflare Pages or GitHub Pages.

## 5. Free deployment with Cloudflare Pages

After pushing to GitHub:

1. Create a Cloudflare account.
2. Go to **Workers & Pages**.
3. Create a Pages project.
4. Connect the GitHub repository.
5. Framework preset: **None**.
6. Build command: leave blank.
7. Build output directory: `/` (repository root).
8. Deploy.

Cloudflare will give you a free `pages.dev` URL.

## 6. Editing later

Content is intentionally simple to edit:

- Main page text → `index.html`
- Colors/layout/responsiveness → `css/style.css`
- Achievements/team/carousel interactions → `js/main.js`
- Images → replace files inside `assets/`

The 13 achievement cards are generated from the `achievements` array in `js/main.js`.

## Note on the gallery overlay

The Figma file currently exposes a scrapbook-style "Our Moments" overlay with one visible chapter spread. The website implements that visible chapter and the gallery modal interaction. Additional hidden/alternate scrapbook chapters can be added later as more Figma states are surfaced.
